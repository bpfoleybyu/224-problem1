#include <stdio.h>
#include <stdlib.h>
#define MAX_SIZE 20

int main(int argc, char* argv[]){
  //pull first, that becomes the size of the array, then initialize the array with that size.
 int size;
 fscanf(stdin, "%d", &size); //read in first int
 printf("next_size = %d\n", size);
 int myArray[size];

 if(size > 20){
 int myArray[20];
}

 int i = 0;

while(i < size){
 fscanf(stdin, "%x", myArray + i);
 //while the array is smaller than its size, keep puling stuff. ignore the rest.
 i++;
}

int cmpfunc (const void * a, const void * b) {
   return ( *(int*)a - *(int*)b );
}

 qsort(myArray, sizeof(myArray)/sizeof(myArray[0]), sizeof(int), cmpfunc);

for(int j = 0; j < sizeof(myArray)/sizeof(myArray[0]); j++){
 fprintf(stdout, "array[j] = %d\n", myArray[j]);
}

 
 //printf("myArray = %d, 
return 0;
}
